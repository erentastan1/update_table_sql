create function ihbar_istek_next_id(v_year integer, v_city_id integer) returns character varying
    language plpgsql
as
$$
DECLARE
v_next_value integer;
v_year_exists int;

v_sleep int;

v_ihbar varchar(17);
BEGIN
lock table ihbar_istek_number_seq in ACCESS EXCLUSIVE mode;

--Yıl a ait veri var mı check set

select count(*) into v_year_exists from ihbar_istek_number_seq where year=v_year and city_id=v_city_id;

if(v_year_exists=0) then

insert into ihbar_istek_number_seq select generate_series(1,81),v_year,0;

end if;

update ihbar_istek_number_seq set counter=counter+1 where year=v_year and city_id=v_city_id returning counter into v_next_value ;

--select 1 from pg_sleep(15) into v_sleep;

v_ihbar:=v_year::varchar||'IHBAR'||lpad(v_city_id::text,2,'0')||lpad(v_next_value::text,6,'0');


RETURN v_ihbar;
END;
$$;

alter function ihbar_istek_next_id(integer, integer) owner to eafad;

