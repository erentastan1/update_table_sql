create function get_organization_shortname(p_organization_id bigint) returns text
    language plpgsql
as
$$
declare

    rec record;

    root_name text;


begin
    select *
    into rec
    from organizasyon where id=p_organization_id;

    if(rec.tip_id = 1 and rec.parent_id != 0 and rec.ulusal_mi=true) then -- ULUSAL Aadym
        with recursive org as
                           (
                               select id,parent_id,0 lvl,ad from organizasyon where id=p_organization_id
                               union all
                               select s.id,s.parent_id,org.lvl+1,s.ad
                               from organizasyon s
                                        inner join org on org.parent_id=s.id
                           )
        select ad
        into root_name
        from org
        where parent_id=0;

        return root_name||'/'||rec.ad||' AADYM';

    elsif(rec.tip_id = 2 and rec.ulusal_mi=true) then -- ULUSAL Servis
        with recursive org as
                           (
                               select id,parent_id,0 lvl,ad from organizasyon where id=p_organization_id
                               union all
                               select s.id,s.parent_id,org.lvl+1,s.ad
                               from organizasyon s
                                        inner join org on org.parent_id=s.id
                           )
        select ad
        into root_name
        from org
        where id=rec.parent_id;

        return root_name||'/'||rec.ad||' Servisi';

    elsif(rec.tip_id = 3 and rec.ulusal_mi=true) then -- ULUSAL Calisma Grubu
        with recursive org as
                           (
                               select id,parent_id,0 lvl,ad from organizasyon where id=p_organization_id
                               union all
                               select s.id,s.parent_id,org.lvl+1,s.ad
                               from organizasyon s
                                        inner join org on org.parent_id=s.id
                           )
        select ad
        into root_name
        from org
        where id=(Select o.parent_id from organizasyon o where rec.parent_id = o.id);

        return root_name||'/'||rec.ad;

    elsif(rec.tip_id = 4 and rec.ulusal_mi=true) then -- ULUSAL Ekip Tipi
       with recursive org as
                           (
                               select id,parent_id,0 lvl,ad,tip_id from organizasyon where id=p_organization_id
                               union all
                               select s.id,s.parent_id,org.lvl+1,s.ad,s.tip_id
                               from organizasyon s
                                        inner join org on org.parent_id=s.id
                           )
        select org.ad||'/'||(select cg.ad from calisma_grubu cg where cg.id=rec.calisma_grubu_id)
        into root_name
        from org
        where tip_id=1
        order by lvl
        limit 1;

        return root_name||'/'||rec.ad||' Ekip Tipi';

    elsif(rec.tip_id = 5 and rec.ulusal_mi=true) then -- ULUSAL Ekip
        select ad
        into root_name
        from calisma_grubu
        where id=rec.calisma_grubu_id;

        return root_name||'/'||rec.ad||' Ekibi';

    elsif(rec.tip_id = 6 and rec.ulusal_mi=true) then -- ULUSAL Alt Ekip
        select (select cg.ad from calisma_grubu cg where cg.id = rec.calisma_grubu_id)||'/'||ad
        into root_name
        from organizasyon o
        where o.id = rec.parent_id;

        return root_name||'/'||rec.ad;

    elsif(rec.ulusal_mi=false and rec.il_kodu is not NULL and rec.ilce_kodu is NULL and rec.tip_id=1) then -- YEREL il aadym
        return rec.ad;

    elsif(rec.ulusal_mi=false and rec.il_kodu is not NULL and rec.ilce_kodu is not NULL and rec.tip_id=1) then -- YEREL ilçe aadym
        select SUBSTR(o.ad, 1, LENGTH(o.ad) - 9)
        into root_name
        from organizasyon o
        where o.id = rec.parent_id;

        return root_name||'/'||rec.ad;

    elsif(rec.ulusal_mi=false and rec.tip_id=2) then -- YEREL servis
        select case when ilce_kodu is null then  c.name else c.name||'/'||d.name end as name
        into root_name
        from organizasyon o
        inner join city c on c.uavt_code=o.il_kodu
        left outer join district d on d.uavt_code = o.ilce_kodu
        where o.id = rec.id;

        return root_name||'/'||rec.ad||' Servisi';

    elsif(rec.ulusal_mi=false and rec.tip_id=3) then -- YEREL çalışma grubu
        select case when ilce_kodu is null then  c.name else c.name||'/'||d.name end as name
        into root_name
        from organizasyon o
        inner join city c on c.uavt_code=o.il_kodu
        left outer join district d on d.uavt_code = o.ilce_kodu
        where o.id = rec.id;

        return root_name||'/'||rec.ad;

    elsif(rec.ulusal_mi=false and rec.tip_id=4) then -- YEREL ekip tipi
        select case when ilce_kodu is null then  c.name else c.name||'/'||d.name end as name
        into root_name
        from organizasyon o
                 inner join city c on c.uavt_code=o.il_kodu
                 left outer join district d on d.uavt_code = o.ilce_kodu
        where o.id = rec.id;

        return root_name||'/'||rec.ad||' Ekip Tipi';

    elsif(rec.ulusal_mi=false and rec.tip_id=5) then -- YEREL ekip
        select case when ilce_kodu is null then  c.name||'/'||trim(replace(cg.ad,'Çalışma Grubu',''))
        else c.name||'/'||d.name||'/'||trim(replace(cg.ad,'Çalışma Grubu','')) end
        into root_name
        from organizasyon o
                 inner join city c on c.uavt_code=o.il_kodu
                 inner join calisma_grubu cg on cg.id = o.calisma_grubu_id
                 left outer join district d on d.uavt_code = o.ilce_kodu
        where o.id = rec.id;

        return root_name||'/'||rec.ad||' Ekibi';

    elsif(rec.ulusal_mi=false and rec.tip_id=6) then -- YEREL alt ekip
        select case when ilce_kodu is null then  c.name||'/'||trim(replace(cg.ad,'Çalışma Grubu',''))||'/'||(select o2.ad from organizasyon o2 where o2.id = rec.parent_id)
            else c.name||'/'||d.name||'/'||trim(replace(cg.ad,'Çalışma Grubu',''))||'/'||(select o2.ad from organizasyon o2 where o2.id = rec.parent_id) end
        into root_name
        from organizasyon o
                 inner join city c on c.uavt_code=o.il_kodu
                 inner join calisma_grubu cg on cg.id = o.calisma_grubu_id
                 left outer join district d on d.uavt_code = o.ilce_kodu
        where o.id = rec.id;

        return root_name||'/'||rec.ad;

    else
        return rec.ad;

    end if;

end
$$;

alter function get_organization_shortname(bigint) owner to eafad;

