create function ayni_bagis_tesis_sayisi(p_bagis_id bigint)
    returns TABLE(kaynak_cesidi_saiyisi numeric)
    language plpgsql
as
$$
DECLARE
    var_r record;
begin

    FOR var_r in (select count(1) kanyak_cesidi_sayisi
                  from (select count(1)
                        from (select tesis_id,
                                     case
                                         when mevcut_miktar - dagitilan_miktar >= 0 then true
                                         else false end status
                              from (select ak.tesis_id,
                                           COALESCE((select eafad.dagitim_dagitilan_miktar_func(kk.id, ak.tesis_id)),
                                                    0)                                                       dagitilan_miktar,
                                           (select eafad.ayni_kaynak_toplam_miktar_func(kk.id, ak.tesis_id)) mevcut_miktar
                                    from tesis_kaynak_bilgileri_group ak
                                             inner join kaynak_kategori kk on kk.id = ak.kaynak_kategori_id
                                             inner join ayni_bagis ab on ab.id = ak.bagis_id
                                    where ak.bagis_id = p_bagis_id) k) m
                        where m.status = true
                        group by m.tesis_id, status) k)
        loop
            kaynak_cesidi_saiyisi = var_r.kanyak_cesidi_sayisi;
            RETURN NEXT;
        END LOOP;
END;
$$;

alter function ayni_bagis_tesis_sayisi(bigint) owner to eafad;

