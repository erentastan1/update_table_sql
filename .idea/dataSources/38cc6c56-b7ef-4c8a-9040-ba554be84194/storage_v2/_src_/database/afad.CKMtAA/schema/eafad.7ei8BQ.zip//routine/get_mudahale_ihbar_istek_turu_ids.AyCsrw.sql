create function get_mudahale_ihbar_istek_turu_ids(p_mudahale_bilgileri_id integer) returns text
    language plpgsql
as
$$
declare

ret_val text;

begin

select string_agg(ii.ihbar_istek_turu_id::text,',' order by ii.ihbar_istek_turu_id)
into ret_val
from mudahale_bilgileri_ihbar_istek mbii
inner join ihbar_istek ii on ii.id = mbii.ihbar_istek_id
where mbii.mudahale_bilgileri_id=p_mudahale_bilgileri_id;

return ret_val;

end;
$$;

alter function get_mudahale_ihbar_istek_turu_ids(integer) owner to eafad;

