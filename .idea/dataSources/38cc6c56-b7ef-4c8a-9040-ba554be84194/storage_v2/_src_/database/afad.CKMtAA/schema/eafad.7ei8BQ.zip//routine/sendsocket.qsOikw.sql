create function sendsocket(msg character varying, host character varying, port integer) returns integer
    language plpython3u
as
$$
  import _socket 
  plpy.notice("1")
  try:
    plpy.notice("1.2")
    s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
    plpy.notice("2")
    s.connect((host, port))
    s.sendall(msg.encode())
    plpy.notice("mesaj gonderildi")
    s.close()
    return 1
  except Exception as e:
    plpy.notice(e)
    return 0
$$;

alter function sendsocket(varchar, varchar, integer) owner to eafad;

