create function kaynak_zayi_toplam_miktar_func(p_kaynak_kategori_id bigint, p_tesis_id bigint, p_grup_id bigint, p_kurum_id bigint) returns numeric
    language plpgsql
as
$$
DECLARE
toplam numeric;
query text;
zayi_miktar numeric;
begin
query :=' select sum(kz.miktar) from kaynak_zayi kz where 1 = 1 ';
query := query || ' and kz.kaynak_id =' || p_kaynak_kategori_id || ' and kz.tesis_id =' || p_tesis_id  ;

if p_grup_id != 0 then
	query := query || ' and kz.tkb_grup_id =' || p_grup_id;
END if;

if p_kurum_id != 0 then
	query := query || ' and kz.kurum_id =' || p_kurum_id;
else
   	query := query || ' and kz.kurum_id is null ';
END if;

query := query ||  ' group by kz.kaynak_id ';
RAISE NOTICE 'query : %', query;

EXECUTE query into toplam;
zayi_miktar := toplam;
return zayi_miktar;


END
$$;

alter function kaynak_zayi_toplam_miktar_func(bigint, bigint, bigint, bigint) owner to eafad;

