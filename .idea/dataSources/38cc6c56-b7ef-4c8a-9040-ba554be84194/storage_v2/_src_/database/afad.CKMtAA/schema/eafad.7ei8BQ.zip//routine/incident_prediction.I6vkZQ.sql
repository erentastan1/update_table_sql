create procedure incident_prediction(x numeric, y numeric, INOUT returntype text, INOUT c_dbuser refcursor)
    language plpgsql
as
$$
declare
/*
returnType:
1:TURKEY
2:WORLD_CITIES
3:SEAS_AND_OCEANS_WITH_TURKEY
4:SEAS_AND_OCEANS
5:DATA_NOT_FOUND
*/

  intersect_count numeric;
  nn_km numeric;
  nn_neighbourhood_id numeric;
  distance numeric;
  streetCount numeric;
  tmp_point GEOMETRY;

begin

returnType := 'DATA_NOT_FOUND';

tmp_point := ST_SetSRID(ST_MakePoint(x, y),4326);

Select count(*) into intersect_count from NEIGHBOURHOOD n where ST_INTERSECTS(n.geometry, tmp_point);

 IF (intersect_count > 0) then
   
    returnType := 'TURKEY';
     			
	select count(*) into streetCount from neighbourhood n  Inner Join  (
		Select * From Street S Where  City_Street_Code !=0 ORDER BY s.geometry <-> tmp_point limit 1
	) Stt On (Stt.Left_Neighbourhood_Id = N.Id Or Stt.Right_Neighbourhood_Id=N.Id) where ST_INTERSECTS(n.geometry, tmp_point);
   
    IF (streetCount > 0) then
   -- dbms_output.put_line('sokak bilgisi var: ' || systimestamp);
   --mahalle uzerindeyse nokta ve sokak varsa
   

    OPEN c_dbuser FOR
     SELECT s.id   subdistrictID,
       s.name subdistrictName,
       c.name cityName,
       c.id   cityID,
       d.name districtName,
       d.id   districtID,
       v.name villageName,
       v.id   villageID,
       n.name neighbourhoodName,
       N.Id   Neighbourhoodid,
       Ns.Neighbourhood_Street_Code neighbourhoodStreetCode,
       stt.name streetName,
       n.geometry
		FROM   subdistrict s,
			   district d,
			   city c,
			   village v,
			   neighbourhood n  Inner Join  (Select * From Street S Where  City_Street_Code !=0 ORDER BY s.geometry <-> tmp_point limit 1) Stt
											On (Stt.Left_Neighbourhood_Id = N.Id Or Stt.Right_Neighbourhood_Id=N.Id)
								inner join neighbourhood_street ns on Stt.City_Street_Code = Ns.City_Street_Code and N.Id = Ns.Neighbourhood_Id
		WHERE  n.uavt_village_code = v.uavt_code
		  AND v.subdistrict_id = s.id
		  AND s.district_id = d.id
		  AND d.city_id = c.id
		  AND ST_INTERSECTS(n.geometry, tmp_point)
		ORDER by  n.name ASC;
                  
        else -- sokak bilgisi yoksa
        --dbms_output.put_line('sokak bilgisi yok: ' || systimestamp);  
        
          OPEN c_dbuser FOR
            SELECT s.id   subdistrictID,
				   s.name subdistrictName,
				   c.name cityName,
				   c.id   cityID,
				   d.name districtName,
				   d.id   districtID,
				   v.name villageName,
				   v.id   villageID,
				   n.name neighbourhoodName,
				   N.Id   Neighbourhoodid,
				   0 neighbourhoodStreetCode,
				   '' streetName,
				   n.geometry
			FROM   subdistrict s,
				   district d,
				   city c,
				   village v,
				   neighbourhood n
			WHERE  n.uavt_village_code = v.uavt_code
			  AND v.subdistrict_id = s.id
			  AND s.district_id = d.id
			  AND d.city_id = c.id
			  AND ST_INTERSECTS(n.geometry, tmp_point)
			ORDER by  n.name ASC;
            END IF;
   ELSE
       intersect_count :=0;
        Select count(*) into intersect_count from WORLD_CITIES w where ST_INTERSECTS(w.geoloc, tmp_point);

        IF (intersect_count > 0) THEN
         --dunya sehirleri uzerindeyse nokta
           returnType := 'WORLD_CITIES';
           OPEN c_dbuser FOR
           
		Select * from WORLD_CITIES w where ST_INTERSECTS(w.geoloc, tmp_point);

        ELSE

          Select count(*) into intersect_count from SEAS_AND_OCEANS w where ST_INTERSECTS(w.geoloc, tmp_point);

           IF (intersect_count > 0) THEN
              --denizdeyse nokta
              Select ST_Distance(n.geometry,tmp_point, 'true') dist into nn_km FROM NEIGHBOURHOOD n  ORDER BY ST_Distance(n.geometry,tmp_point) limit 1;
			  
			--Sabit 100000 olarak çekilmiş. Metre cinsinden.
              Select 100000 into distance;

              IF (nn_km < distance) THEN
                 --turkiyeye 100 km yak?nsa
                 returnType := 'SEAS_AND_OCEANS_WITH_TURKEY';
                OPEN c_dbuser FOR
                  SELECT      s.id   subdistrictID,
								s.name subdistrictName,
								c.name cityName,
								c.id   cityID,
								d.name districtName,
								d.id   districtID,
								v.name villageName,
								v.id   villageID,
								n.name neighbourhoodName,
								n.id   neighbourhoodID,
								w.name seaName,
								w.id   seaId,
								w.geoloc geoloc
					FROM   subdistrict s,
						   district d,
						   city c,
						   village v,
						   neighbourhood n,
						   SEAS_AND_OCEANS w
					WHERE  n.uavt_village_code = v.uavt_code
					  AND v.subdistrict_id = s.id
					  AND s.district_id = d.id
					  AND d.city_id = c.id
					  AND n.id =
						  (Select n.id FROM NEIGHBOURHOOD n  ORDER BY n.geometry <-> tmp_point limit 1)
					  AND w.id =
						  (Select ss.id from SEAS_AND_OCEANS ss where ST_INTERSECTS(ss.geoloc, tmp_point))
					ORDER by n.name ASC;


               ELSE
                 --turkiyeden 100 km uzaksa
                 returnType := 'SEAS_AND_OCEANS';
                 OPEN c_dbuser FOR
                     Select w.name seaName, w.id seaId from SEAS_AND_OCEANS w where ST_INTERSECTS(w.geoloc, tmp_point) ORDER  BY w.name ASC;

              END IF;

           END IF;

        END IF;

   END IF;




end;
$$;

alter procedure incident_prediction(numeric, numeric, inout text, inout refcursor) owner to eafad;

