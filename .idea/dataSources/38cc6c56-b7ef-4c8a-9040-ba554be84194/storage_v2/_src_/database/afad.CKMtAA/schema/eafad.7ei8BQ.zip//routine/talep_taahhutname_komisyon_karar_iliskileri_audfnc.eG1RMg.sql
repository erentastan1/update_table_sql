create function talep_taahhutname_komisyon_karar_iliskileri_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'DELETE') THEN
INSERT INTO EAFAD.TALEP_TAAHHUTNAME_KOMISYON_KARAR_ILISKILERI_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
 RETURN OLD;
ELSIF (TG_OP = 'UPDATE') THEN
INSERT INTO EAFAD.TALEP_TAAHHUTNAME_KOMISYON_KARAR_ILISKILERI_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
RETURN NEW;
ELSIF (TG_OP = 'INSERT') THEN
INSERT INTO EAFAD.TALEP_TAAHHUTNAME_KOMISYON_KARAR_ILISKILERI_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
RETURN NEW;
END IF;
RETURN NULL;
END;
$$;

alter function talep_taahhutname_komisyon_karar_iliskileri_audfnc() owner to eafad;

