create function get_barinma_alani_destek_ids(p_barinma_detay_id bigint) returns text
    language plpgsql
as
$$
declare

ret_val text;

begin

select string_agg(bas.destek_id::text, ',' order by bas.destek_id)  destek_ids
into ret_val
from barinma_alani_destekleri bas
where bas.barinma_detay_id=p_barinma_detay_id;

return ret_val;

end;
$$;

alter function get_barinma_alani_destek_ids(bigint) owner to eafad;

