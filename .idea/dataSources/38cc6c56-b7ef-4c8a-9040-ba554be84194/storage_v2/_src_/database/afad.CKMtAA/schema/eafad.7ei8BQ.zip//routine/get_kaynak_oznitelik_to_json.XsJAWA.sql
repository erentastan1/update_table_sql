create function get_kaynak_oznitelik_to_json(p_kaynak_id bigint, p_tesis_id bigint, p_kurum_id bigint, p_group_id bigint) returns json
    language plpgsql
as
$$
DECLARE
results text;
query text;
begin
query :='select case when cnt = 0 then null else oznitelikJson end   from (select count(kkol.id) cnt, json_agg(case when kkol.adi is not null then concat(kkol.adi, '' - '',';
query := query ||  ' (CASE WHEN tkb.number_value is not null and tkb.oznitelik_id!=';
query := query ||  ' (select id from kaynak_kategori_oznitelik_listesi where adi = ''Miktar'')';
query := query ||  ' THEN ( '''' ) ::TEXT  WHEN tkb.number_value is not null ';
query := query ||  ' and tkb.oznitelik_id in (select id from kaynak_kategori_oznitelik_listesi where adi != ''Miktar'')';
query := query ||  ' THEN tkb.number_value ::TEXT  WHEN tkb.string_value is not null AND tkb.string_value != ''''  ';
query := query ||  ' THEN tkb.string_value ::TEXT  WHEN tkb.date_value is not null THEN tkb.date_value ::TEXT ';
query := query ||  ' WHEN tkb.list_value > 0 THEN (Select kkoldl.deger From kaynak_kategori_oznitelik_liste_degerleri_listesi kkoldl';
query := query ||  ' Where kkoldl.id = tkb.list_value)::TEXT END)) else '''' end ) as oznitelikJson';
query := query ||  ' from tesis_kaynak_bilgileri tkb inner join kaynak_kategori kk on tkb.kaynak_kategori_id = kk.id and kk.dagitilabilir_kaynak=false';
query := query ||  ' left join kaynak_kategori_oznitelik_listesi kkol on kkol.id =tkb.oznitelik_id and kkol.adi != ''Miktar''';
query := query ||  ' inner join tesis_kaynak_bilgileri_group tkbg on tkb.group_id = tkbg.tesis_kaynak_bilgileri_group_id ';
query := query ||  ' where kk.id=' || p_kaynak_id || ' and tkbg.tesis_id='|| p_tesis_id  ;

--RAISE NOTICE 'query : %', query;

if p_kurum_id != 0 then
	query := query || ' and tkbg.kurum_id =' || p_kurum_id;
else
   	query := query || ' and tkbg.kurum_id is null ';
END if;

query := query || ' and tkbg.tesis_kaynak_bilgileri_group_id =' || p_group_id;

query := query || ' ) t1' ;

EXECUTE query into results;

return results;
RAISE NOTICE 'query : %', query;

END
$$;

alter function get_kaynak_oznitelik_to_json(bigint, bigint, bigint, bigint) owner to eafad;

