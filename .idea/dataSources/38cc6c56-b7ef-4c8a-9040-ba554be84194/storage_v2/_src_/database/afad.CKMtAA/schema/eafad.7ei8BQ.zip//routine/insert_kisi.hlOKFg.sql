create function insert_kisi(tcno character varying) returns refcursor
    language plpgsql
as
$$
DECLARE
    kisiId refcursor;
    kullaniciId refcursor;
BEGIN
    OPEN kisiId FOR SELECT nextval('kisi_seq');
    insert into kisi (id, tc_kimlik_no, ad, soyad, e_posta,uyruk_id)
    values (kisiId  ,tcNo, 'Tayfun', 'BAŞER', 'tayfun.baser@afad.gov.tr',20020001);

    insert into kullanici (id, kisi_id, kullanici_adi, ldap_server_id)
    values (nextval('kullanici_seq'), kisi_id, 'tayfun.baser', 1);

    -- Open a cursor
    RETURN kisiId;                                                       -- Return the cursor to the caller
END;
$$;

alter function insert_kisi(varchar) owner to eafad;

