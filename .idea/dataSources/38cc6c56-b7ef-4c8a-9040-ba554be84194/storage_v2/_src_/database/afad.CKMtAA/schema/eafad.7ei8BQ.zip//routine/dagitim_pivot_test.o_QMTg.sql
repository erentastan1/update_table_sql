create function dagitim_pivot_test(p_kaynak_kategori_id bigint) returns void
    language plpgsql
as
$$
DECLARE
    var_r record;
   	tt text;
   	sql record;
begin
	 select * into var_r from crosstab(' select
    kkol.adi as adi,
    case when kkol.deger_tipi = 1 then tkb.string_value::text
         when kkol.deger_tipi = 2 then tkb.number_value::text
         when kkol.deger_tipi = 3 then tkb.date_value::text
         when kkol.deger_tipi = 4 then kkoldl.deger::text
         when kkol.deger_tipi = 5 then tkb.number_value::text
        end as res
from kaynak_dagitim_oznitelik tkb
         left join kaynak_kategori_oznitelik_listesi kkol on kkol.id = tkb.oznitelik_id
         left join kaynak_kategori_oznitelik_liste_degerleri_listesi kkoldl on kkoldl.id = tkb.list_value ORDER  BY 1,2',7);
		raise notice 'Value: %', var_r;
END;
$$;

alter function dagitim_pivot_test(bigint) owner to eafad;

