create procedure yerel_aadym_city_creator(p_parent_id bigint, p_organizasyon_adi text, p_ulusal_mi boolean, p_tip_id bigint)
    language plpgsql
as
$$
declare
  r           record;
  v_il_org_id bigint;
  hasAADYM    int;
begin
  for r in (select id, name, uavt_code from eafad.city order by id)
    loop
      select count(1) into hasAADYM
      from organizasyon
      where parent_id = p_parent_id
        and lower(ad) = lower(p_organizasyon_adi || ' ' || r.name || ' İl AADYM');
      if hasAADYM <= 0 then
        v_il_org_id := nextval('eafad.organizasyon_seq');
        insert into eafad.organizasyon
        values (v_il_org_id, p_parent_id, p_ulusal_mi, p_tip_id, p_organizasyon_adi || ' ' || r.name || ' İl AADYM',r.uavt_code,null);
      end if;
    end loop;
end;
$$;

alter procedure yerel_aadym_city_creator(bigint, text, boolean, bigint) owner to eafad;

