create function test_tt(p_pattern character varying, p_year integer)
    returns TABLE(ad character varying, soyad character varying)
    language plpgsql
as
$$
DECLARE 
    var_r record;
BEGIN
	FOR var_r IN(SELECT 
						adi, 
						soyadi 
                FROM AYNI_BAGIS_YAPAN_KISI  )
	LOOP
        ad := upper(var_r.adi) ; 
		soyad := var_r.soyadi;
        RETURN NEXT;
	END LOOP;
END;
$$;

alter function test_tt(varchar, integer) owner to eafad;

