create function kaynak_parent_name(p_kategori_id bigint) returns character varying
    language plpgsql
as
$$
DECLARE
query text;
    parent varchar;
begin
query := ' (
			WITH RECURSIVE parents( id, parent_id,adi )AS
			(
				SELECT id, parent_id,adi FROM kaynak_kategori
				WHERE id = '|| p_kategori_id ||'
				UNION ALL
				SELECT t.id, t.parent_id,t.adi	FROM parents p
				JOIN kaynak_kategori t ON p.parent_id = t.id
			)
			SELECT adi from parents order by parent_id limit 1
			)
			';


EXECUTE  query into parent;

return parent;

RAISE NOTICE 'query : %', query;

END
$$;

alter function kaynak_parent_name(bigint) owner to eafad;

