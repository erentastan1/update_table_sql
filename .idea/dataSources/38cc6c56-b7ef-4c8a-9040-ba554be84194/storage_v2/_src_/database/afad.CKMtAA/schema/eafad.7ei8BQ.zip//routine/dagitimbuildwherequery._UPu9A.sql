create function dagitimbuildwherequery(test json)
    returns TABLE(wherequery text)
    language plpgsql
as
$$
declare
    i json;
	whereClause text;
	key_p text;
	value_p text;


begin	
	whereClause:=' ';
	FOR i IN SELECT * FROM json_array_elements(test)
  loop
  	key_p:=i->>'key';
  	value_p:=i->>'value';
  	--whereClause = whereClause ||' and ' ||'"'|| key_p  ||'"'|| '=' || ''''|| value_p::text || '''';
  	whereClause = whereClause || format(' and exists
			(
			select
			1 
			from 
			kaynak_dagitim_oznitelik tkb
			inner join kaynak_dagitim kd2 on kd2.grup_id = tkb.grup_id
			inner join kaynak_kategori kk on kk.id = kd.kaynak_kategori_id
			left join kaynak_kategori_oznitelik_listesi kkol on kkol.id = tkb.oznitelik_id
			left join kaynak_kategori_oznitelik_liste_degerleri_listesi kkoldl on kkoldl.id = tkb.list_value  
			where  kd.id=kd2.id
				and kkol.adi=''%s''
			and 
			case when kkol.deger_tipi = 1 then tkb.string_value::text
			when kkol.deger_tipi = 2 then tkb.number_value::text
			when kkol.deger_tipi = 3 then tkb.date_value::text
			when kkol.deger_tipi = 4 then kkoldl.deger::text
			when kkol.deger_tipi = 5 then tkb.number_value::text
			end =''%s'' 
			)',i->>'key',i->>'value') ;
    RAISE NOTICE 'output from space key : %', i->>'key';
   RAISE NOTICE 'output from space value : %', i->>'value';
  END LOOP;
  RAISE NOTICE 'clouse : %', whereClause;
  
  whereQuery:= whereClause;
  return next;
END
$$;

alter function dagitimbuildwherequery(json) owner to eafad;

