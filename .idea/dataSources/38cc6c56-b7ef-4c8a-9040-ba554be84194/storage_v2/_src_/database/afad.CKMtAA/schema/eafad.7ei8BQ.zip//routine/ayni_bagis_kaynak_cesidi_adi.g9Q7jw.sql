create function ayni_bagis_kaynak_cesidi_adi(p_bagis_id bigint)
    returns TABLE(kaynak_cesidi_sayisi character varying)
    language plpgsql
as
$$
DECLARE
    var_r record;
begin

    FOR var_r in (
select string_agg(distinct ss.adi::text, ',') adi_r
from (select adi from (
               select (SELECT string_agg(SS.PATH::text, ',') FROM (with recursive k_kategori as
                                                                                      (
                                                                                          select id,parent_id,adi path,array[id] ids from kaynak_kategori where id in (SELECT kk.id FROM ayni_kaynak ak inner join kaynak_kategori kk on ak.kaynak_kategori_id = kk.id  where ak.ayni_bagis_id = p_bagis_id group by kk.id)
                                                                                          union all
                                                                                          select k.id,k.parent_id,k.adi,ids||k.id from kaynak_kategori k inner join k_kategori kat on kat.parent_id=k.id
                                                                                      )
                                                                   select kat2.path from k_kategori kat2
                                                                   where 1=1 and kat2.parent_id not in (select id from k_kategori) group by kat2.path) SS) adi,
                      (select status
                       from eafad.ayni_kaynak_dagitim_degerleri(ak.tesis_id, ab.olay_id,
                                                                ak.kategori_birim_id,
                                                                ak.kaynak_kategori_id))
               from ayni_kaynak ak
                        inner join kaynak_kategori kk on kk.id = ak.kaynak_kategori_id
                        inner join ayni_bagis ab on ab.id = ak.ayni_bagis_id
               where ak.ayni_bagis_id = p_bagis_id
           ) m
      where m.status = true) SS)
        loop
            kaynak_cesidi_sayisi = var_r.adi_r;
            RETURN NEXT;
        END LOOP;
END;
$$;

alter function ayni_bagis_kaynak_cesidi_adi(bigint) owner to eafad;

