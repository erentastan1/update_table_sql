create function get_ihbar_istek_cg_ids(p_ihbar_istek_id integer) returns text
    language plpgsql
as
$$
declare

ret_val text;

begin

SELECT string_agg(DISTINCT calisma_grubu_id::text,',')
into ret_val
FROM ihbar_istek_calisma_grubu
WHERE ihbar_istek_id = p_ihbar_istek_id;

return ret_val;

end;
$$;

alter function get_ihbar_istek_cg_ids(integer) owner to eafad;

