create function mytriggertosendsockets() returns trigger
    language plpython3u
as
$$
   stmt2 =plpy.prepare("select count(*) from eafad.deneme")
   rv2 = plpy.execute(stmt2)
   plpy.notice(rv2)
   stmt = plpy.prepare("select eafad.sendsocket($1, $2, $3)", ["text", "text", "int"])
   rv = plpy.execute(stmt, [rv2, '10.100.33.204', 5601])
$$;

alter function mytriggertosendsockets() owner to eafad;

