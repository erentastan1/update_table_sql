create function get_mudahale_ihbar_istek_ids(p_mudahale_bilgileri_id integer) returns text
    language plpgsql
as
$$
declare

ret_val text;

begin

select string_agg(ihbar_istek_id::text,',' order by ihbar_istek_id)
into ret_val
from mudahale_bilgileri_ihbar_istek
where mudahale_bilgileri_id=p_mudahale_bilgileri_id;

return ret_val;

end;
$$;

alter function get_mudahale_ihbar_istek_ids(integer) owner to eafad;

