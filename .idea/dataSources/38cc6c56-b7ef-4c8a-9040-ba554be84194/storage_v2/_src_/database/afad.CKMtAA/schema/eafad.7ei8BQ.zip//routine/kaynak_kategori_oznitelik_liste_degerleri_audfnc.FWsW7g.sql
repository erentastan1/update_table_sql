create function kaynak_kategori_oznitelik_liste_degerleri_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO EAFAD.KAYNAK_KATEGORI_OZNITELIK_LISTE_DEGERLERI_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO EAFAD.KAYNAK_KATEGORI_OZNITELIK_LISTE_DEGERLERI_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO EAFAD.KAYNAK_KATEGORI_OZNITELIK_LISTE_DEGERLERI_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

alter function kaynak_kategori_oznitelik_liste_degerleri_audfnc() owner to eafad;

