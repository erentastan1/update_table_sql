create function ayni_tesis_control_list(p_bagis_id bigint)
    returns TABLE(tesis_ad character varying, tesis_id integer, kaynak_id integer, miktar numeric, dagitilan_miktar numeric, status boolean)
    language plpgsql
as
$$
DECLARE
    var_r record;
begin

	FOR var_r in ( select t.ad,t.id,ak.miktar,ak.id kaynak_id, (select sum(gg.miktar) from ayni_dagitim_kaynak gg where gg.ayni_kaynak_id = ak.id) dagitilan  from ayni_kaynak ak  inner  join tesis t on ak.tesis_id = t.id  where ak.ayni_bagis_id = p_bagis_id )
	loop

        tesis_ad := upper(var_r.ad) ;
		tesis_id := var_r.id;
		kaynak_id := var_r.kaynak_id;
		miktar := var_r.miktar;
		dagitilan_miktar := var_r.dagitilan;
		if miktar > dagitilan_miktar or dagitilan_miktar is null then
			status := true;
		else
			status = false;
		end if;
        RETURN NEXT;
	END LOOP;
END;
$$;

alter function ayni_tesis_control_list(bigint) owner to eafad;

