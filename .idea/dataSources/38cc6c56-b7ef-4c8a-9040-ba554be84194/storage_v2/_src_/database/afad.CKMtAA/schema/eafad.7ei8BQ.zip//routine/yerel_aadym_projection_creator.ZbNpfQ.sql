create procedure yerel_aadym_projection_creator(p_parent_id bigint, p_organizasyon_adi text, p_tip_id bigint)
    language plpgsql
as
$$
declare
  r           record;
  v_il_org_id bigint;
  hasObject   bigint;

begin

  /**select * into mirror_object from organizasyon o2 where o2.tip_id =  p_type_id and id = mirror_object_id;*/


  for r in (with recursive org (id, parent_id, ad, ulusal_mi, tip_id) as
                             (
                               select id
                                    , parent_id
                                    , ad
                                    , ulusal_mi
                                    , tip_id
                               from organizasyon o1
                               where o1.parent_id = p_parent_id
                               union all
                               select o2.id
                                    , o2.parent_id
                                    , o2.ad
                                    , o2.ulusal_mi
                                    , o2.tip_id
                               from organizasyon o2
                                      inner join org on o2.parent_id = org.id
                             )
            select *
            from org)
    loop
      if p_tip_id = 2 and r.tip_id = 1 then /** gelen servis ise (tip = 2) aadym tipindekilerin (tip = 1) altına ekleniyor  */

        raise notice 'Value: %', r.id;
        v_il_org_id := nextval('eafad.organizasyon_seq');
        select count(1) into hasObject
        from organizasyon o2
        where o2.parent_id = r.id
          and o2.tip_id = p_tip_id
          and lower(o2.ad) = p_organizasyon_adi;
        if (hasObject = 0) then

          insert into eafad.organizasyon
          values (v_il_org_id, r.id, false, p_tip_id, p_organizasyon_adi);
        end if;

      elseif p_tip_id = 3 and r.tip_id = 2 then /** gelen çalışma grubu ise (tip = 3) servislerin tipindekilerin (tip = 2) altına ekleniyor  */

        v_il_org_id := nextval('eafad.organizasyon_seq');
        select count(1) into hasObject
        from organizasyon o2
        where o2.parent_id = r.id
          and o2.tip_id = p_tip_id
          and lower(o2.ad) = p_organizasyon_adi;
        if (hasObject = 0) then

          insert into eafad.organizasyon
          values (v_il_org_id, r.id, false, p_tip_id, p_organizasyon_adi);
        end if;

      elseif p_tip_id = 4 and r.tip_id = 3 then /** gelen ekip tipi ise (tip = 4) çalışma grubu tipindekilerin (tip = 3) altına ekleniyor  */

        v_il_org_id := nextval('eafad.organizasyon_seq');
        select count(1) into hasObject
        from organizasyon o2
        where o2.parent_id = r.id
          and o2.tip_id = p_tip_id
          and lower(o2.ad) = p_organizasyon_adi;
        if (hasObject = 0) then
          insert into eafad.organizasyon
          values (v_il_org_id, r.id, false, p_tip_id, p_organizasyon_adi);
        end if;

      elseif p_tip_id = 5 and r.tip_id = 4 then /** gelen ekip ise (tip = 5) ekip tipindekilerin (tip = 4) altına ekleniyor  */

        v_il_org_id := nextval('eafad.organizasyon_seq');
        select count(1) into hasObject
        from organizasyon o2
        where o2.parent_id = r.id
          and o2.tip_id = p_tip_id
          and lower(o2.ad) = p_organizasyon_adi;
        if (hasObject = 0) then
          insert into eafad.organizasyon
          values (v_il_org_id, r.id, false, p_tip_id, p_organizasyon_adi);
        end if;
      end if;

    end loop;
end;
$$;

alter procedure yerel_aadym_projection_creator(bigint, text, bigint) owner to eafad;

