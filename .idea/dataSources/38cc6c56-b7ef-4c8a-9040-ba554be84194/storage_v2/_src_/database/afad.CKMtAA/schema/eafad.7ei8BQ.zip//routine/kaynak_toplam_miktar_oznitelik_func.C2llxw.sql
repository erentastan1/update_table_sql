create function kaynak_toplam_miktar_oznitelik_func(p_kaynak_kategori_id integer, p_tesis_id integer, p_whereclause text) returns integer
    language plpgsql
as
$$
DECLARE
    toplam numeric;
    query text;
    dagitilan_miktar integer;
begin
    query:='select   sum(gg.number_value)
from tesis_kaynak_bilgileri_group kd
         inner join (select kdo.* from tesis_kaynak_bilgileri kdo  LEFT JOIN kaynak_kategori_oznitelik_listesi kkol on kkol.id = kdo.oznitelik_id where deger_tipi = 5) gg on gg.group_id = kd.tesis_kaynak_bilgileri_group_id
where kd.bagis_id is  null and 1=1';

    query := query || kaynak_build_where_query_key(p_whereClause);

    query := query || ' and kd.kaynak_kategori_id =' || p_kaynak_kategori_id || ' and kd.tesis_id =' || p_tesis_id;

    query := query ||  '  group by kd.kaynak_kategori_id ';
    RAISE NOTICE 'query : %', query;
    EXECUTE  query into toplam;
    dagitilan_miktar := toplam;

    return dagitilan_miktar;


END
$$;

alter function kaynak_toplam_miktar_oznitelik_func(integer, integer, text) owner to eafad;

