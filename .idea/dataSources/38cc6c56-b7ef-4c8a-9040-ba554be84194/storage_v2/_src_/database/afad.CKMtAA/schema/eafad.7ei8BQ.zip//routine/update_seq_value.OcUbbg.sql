create function update_seq_value(sequence_name character varying, increment_by integer) returns integer
    language plpgsql
as
$$
declare

retval int;

v_result int;

begin

execute 'select last_value from '||sequence_name  into retval;

retval:=retval+increment_by;

SELECT setval(sequence_name, retval, true) into v_result;  

return v_result;

END;
$$;

alter function update_seq_value(varchar, integer) owner to eafad;

