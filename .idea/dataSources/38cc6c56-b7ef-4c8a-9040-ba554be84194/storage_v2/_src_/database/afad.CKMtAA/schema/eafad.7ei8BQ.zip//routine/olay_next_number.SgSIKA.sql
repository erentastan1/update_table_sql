create function olay_next_number(v_year integer, v_city_id integer) returns character varying
    language plpgsql
as
$$
DECLARE
    v_next_value integer;
    v_year_exists int;

    v_sleep int;

    v_olay varchar(17);
BEGIN
    lock table olay_numarasi_seq in ACCESS EXCLUSIVE mode;

--Yıl a ait veri var mı check set

    select count(*) into v_year_exists from olay_numarasi_seq where year=v_year and city_id=v_city_id;

    if(v_year_exists=0) then

        insert into olay_numarasi_seq select generate_series(1,82),v_year,0;
        insert into olay_numarasi_seq select 1001,v_year,0;
        insert into olay_numarasi_seq select 1002,v_year,0;
        insert into olay_numarasi_seq select 1003,v_year,0;
    end if;

    update olay_numarasi_seq set counter=counter+1 where year=v_year and city_id=v_city_id returning counter into v_next_value ;

--select 1 from pg_sleep(15) into v_sleep;
    IF (v_city_id <= 81) then
        v_olay := v_year::varchar || lpad(v_city_id::text, 2, '0') || lpad(v_next_value::text, 5, '0');
--Yurt dışı depremler için insert edilir.
    ELSIF  (v_city_id = 1001) then
        v_olay := v_year::varchar || 'YD' || lpad(v_next_value::text, 5, '0');
--Denizde olan depremler için insert edilir.
    ELSIF  (v_city_id = 1002) then
        v_olay := v_year::varchar || 'DZ' || lpad(v_next_value::text, 5, '0');
	ELSIF  (v_city_id = 1003) then
	v_olay := v_year::varchar || 'TB' || lpad(v_next_value::text, 5, '0');
    END IF;

    RETURN v_olay;
END;
$$;

alter function olay_next_number(integer, integer) owner to eafad;

