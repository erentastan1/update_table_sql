create function ihbar_istek_turu_calisma_grubu_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'DELETE') THEN
INSERT INTO IHBAR_ISTEK_TURU_CALISMA_GRUBU_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
 RETURN OLD;
ELSIF (TG_OP = 'UPDATE') THEN
INSERT INTO IHBAR_ISTEK_TURU_CALISMA_GRUBU_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
RETURN NEW;
ELSIF (TG_OP = 'INSERT') THEN
INSERT INTO IHBAR_ISTEK_TURU_CALISMA_GRUBU_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
RETURN NEW;
END IF;
RETURN NULL;
END;
$$;

alter function ihbar_istek_turu_calisma_grubu_audfnc() owner to eafad;

