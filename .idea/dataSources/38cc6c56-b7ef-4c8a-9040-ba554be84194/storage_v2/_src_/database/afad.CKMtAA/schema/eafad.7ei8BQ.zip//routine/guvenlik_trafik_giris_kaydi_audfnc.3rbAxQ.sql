create function guvenlik_trafik_giris_kaydi_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'DELETE') THEN
INSERT INTO EAFAD.GUVENLIK_TRAFIK_GIRIS_KAYDI_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
 RETURN OLD;
ELSIF (TG_OP = 'UPDATE') THEN
INSERT INTO EAFAD.GUVENLIK_TRAFIK_GIRIS_KAYDI_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
RETURN NEW;
ELSIF (TG_OP = 'INSERT') THEN
INSERT INTO EAFAD.GUVENLIK_TRAFIK_GIRIS_KAYDI_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
RETURN NEW;
END IF;
RETURN NULL;
END;
$$;

alter function guvenlik_trafik_giris_kaydi_audfnc() owner to eafad;

