create procedure yerel_ekip_yansitma(p_parent_id bigint, p_organizasyon_adi text, p_tip_id bigint, p_parent_adi text, p_calisma_grubu_id bigint)
    language plpgsql
as
$$
declare
  r           record;
  v_il_org_id bigint;
  hasObject   bigint;

begin

  for r in (with recursive org (id, parent_id, ad, ulusal_mi, tip_id,il_kodu,ilce_kodu,calisma_grubu_id) as
                             (
                               select id
                                    , parent_id
                                    , ad
                                    , ulusal_mi
                                    , tip_id
                                    , il_kodu
                                    , ilce_kodu
                                    , calisma_grubu_id
                               from organizasyon o1
                               where o1.ulusal_mi = false and o1.tip_id = 4 and o1.id != p_parent_id
                               union all
                               select o2.id
                                    , o2.parent_id
                                    , o2.ad
                                    , o2.ulusal_mi
                                    , o2.tip_id
                                    , o2.il_kodu
                                    , o2.ilce_kodu
                                    , o2.calisma_grubu_id
                               from organizasyon o2
                                      inner join org on o2.parent_id = org.id
                             )
            select *
            from org)
    loop
      if p_tip_id = 5 and r.tip_id = 4 and r.calisma_grubu_id = p_calisma_grubu_id and r.ad LIKE p_parent_adi and (r.il_kodu > 0 or r.ilce_kodu > 0) then

        raise notice 'Value: %', r.id;
        v_il_org_id := nextval('eafad.organizasyon_seq');

        select count(1) into hasObject
        from organizasyon o2
        where o2.parent_id = r.id
          and o2.tip_id = p_tip_id
          and lower(o2.ad) = lower(p_organizasyon_adi);
        if (hasObject = 0) then

          insert into eafad.organizasyon
          values (v_il_org_id, r.id, false, p_tip_id, p_organizasyon_adi,r.il_kodu,r.ilce_kodu, p_calisma_grubu_id);
        end if;

      end if;

    end loop;
end;
$$;

alter procedure yerel_ekip_yansitma(bigint, text, bigint, text, bigint) owner to eafad;

