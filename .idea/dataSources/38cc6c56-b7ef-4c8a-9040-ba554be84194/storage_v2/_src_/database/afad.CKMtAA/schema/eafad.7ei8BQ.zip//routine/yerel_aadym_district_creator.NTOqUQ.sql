create procedure yerel_aadym_district_creator(p_city_id bigint, p_parent_id bigint, p_organizasyon_adi text, p_ulusal_mi boolean, p_tip_id bigint)
    language plpgsql
as
$$
declare
  r           record;
   t           record;
  v_il_org_id bigint;
  hasAADYM    int;
  totalAADYMCount    int;

begin
  for r in (select id, name, uavt_code from eafad.city where id = p_city_id)
    loop

    select count(1) into hasAADYM
      from organizasyon
      where parent_id = p_parent_id
        and lower(ad) = lower(p_organizasyon_adi || ' ' || r.name || ' İl AADYM');


   		select count(1) into totalAADYMCount
      from organizasyon
      where lower(ad) = lower(p_organizasyon_adi || ' ' || r.name || ' İl AADYM');


      if hasAADYM <= 0 then
      v_il_org_id := nextval('eafad.organizasyon_seq');
      insert into eafad.organizasyon
      values (v_il_org_id, p_parent_id, p_ulusal_mi, p_tip_id, p_organizasyon_adi || ' ' || r.name || ' İl AADYM',r.uavt_code,null);
      insert into eafad.organizasyon
      select nextval('eafad.organizasyon_seq'),
             v_il_org_id,
             p_ulusal_mi,
             p_tip_id,
             p_organizasyon_adi || ' ' || d.name || ' İlçe AADYM',
             d.city_id,
             d.uavt_code
      from eafad.district d
      where d.city_id = r.id;
       elseif totalAADYMCount > 0 then
         for t in (select id
                  from organizasyon
                  where  lower(ad) = lower(p_organizasyon_adi || ' ' || r.name || ' İl AADYM'))

		  loop
            insert into eafad.organizasyon
            select nextval('eafad.organizasyon_seq'),
                   t.id,
                   p_ulusal_mi,
                   p_tip_id,
                   p_organizasyon_adi || ' ' || d.name || ' İlçe AADYM',
                   d.city_id,
                   d.uavt_code
            from eafad.district d
            where d.city_id = r.id;
           end loop;
      end if;

    end loop;
end;
$$;

alter procedure yerel_aadym_district_creator(bigint, bigint, text, boolean, bigint) owner to eafad;

