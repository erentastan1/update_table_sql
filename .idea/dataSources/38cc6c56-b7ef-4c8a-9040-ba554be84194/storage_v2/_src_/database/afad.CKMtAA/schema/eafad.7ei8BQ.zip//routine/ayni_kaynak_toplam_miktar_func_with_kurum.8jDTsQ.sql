create function ayni_kaynak_toplam_miktar_func_with_kurum(p_kaynak_kategori_id bigint, p_tesis_id bigint, p_kurum_id bigint, p_group_id bigint) returns numeric
    language plpgsql
as
$$
DECLARE
toplam numeric;
    query
text;
    top_miktar
numeric;
begin
   query:='select sum(kd.miktar) from tesis_kaynak_bilgileri_group kd
         inner join kaynak_kategori kk on kk.id = kd.kaynak_kategori_id
where 1 = 1 ';

query:= query || ' and kd.kaynak_kategori_id =' || p_kaynak_kategori_id || ' and kd.tesis_id =' || p_tesis_id  ;


if p_kurum_id != 0 then
	query := query || ' and kd.kurum_id =' || p_kurum_id;
else
   	query := query || ' and kd.kurum_id is null ';
END if;


if p_group_id != 0 then
	query := query || ' and kd.tesis_kaynak_bilgileri_group_id =' || p_group_id;
END if;

RAISE
NOTICE 'query : %', query;
EXECUTE query into toplam;
top_miktar:= toplam;

return top_miktar;

END
$$;

alter function ayni_kaynak_toplam_miktar_func_with_kurum(bigint, bigint, bigint, bigint) owner to eafad;

