create function barinma_detay_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'DELETE') THEN
INSERT INTO EAFAD.BARINMA_DETAY_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
 RETURN OLD;
ELSIF (TG_OP = 'UPDATE') THEN
INSERT INTO EAFAD.BARINMA_DETAY_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
RETURN NEW;
ELSIF (TG_OP = 'INSERT') THEN
INSERT INTO EAFAD.BARINMA_DETAY_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
RETURN NEW;
END IF;
RETURN NULL;
END;
$$;

alter function barinma_detay_audfnc() owner to eafad;

