create function afetzede_next_id(p_olay_no character varying) returns character varying
    language plpgsql
as
$$
declare

v_olay_exists int;

v_ret_val varchar(100);

v_next_value int;

begin

lock table eafad.afetzede_number_seq in ACCESS EXCLUSIVE mode;

select count(*) into v_olay_exists from eafad.afetzede_number_seq where olay_no=p_olay_no limit 1;

if(v_olay_exists=0) then

insert into eafad.afetzede_number_seq values(p_olay_no,0);

end if;

update eafad.afetzede_number_seq set counter=counter+1
where olay_no=p_olay_no
returning counter into v_next_value ;

v_ret_val:=p_olay_no||v_next_value::text;

return v_ret_val;

end
$$;

alter function afetzede_next_id(varchar) owner to eafad;

