create function ayni_kaynak_controllist(p_bagis_id bigint)
    returns TABLE(kategori_adi character varying, kategori_id integer, id integer, miktar numeric, kategori_birim_id integer, dagitilan_miktar numeric, status boolean)
    language plpgsql
as
$$
DECLARE
    var_r record;
begin

	FOR var_r in ( select ak.*,kk.adi,ak.kaynak_kategori_id ,(select sum(gg.miktar) from ayni_dagitim_kaynak gg where gg.ayni_kaynak_id = ak.id) dagitilan  from ayni_kaynak ak inner join kaynak_kategori kk on kk.id = ak.kaynak_kategori_id where ak.ayni_bagis_id =  p_bagis_id )
	loop

        kategori_adi := upper(var_r.adi) ;
		id := var_r.id;
		miktar := var_r.miktar;
		kategori_id := var_r.kaynak_kategori_id;
		dagitilan_miktar := var_r.dagitilan;
		kategori_birim_id := var_r.kategori_birim_id;
		if miktar > dagitilan_miktar or dagitilan_miktar is null then
			status := true;
		else
			status = false;
		end if;
        RETURN NEXT;
	END LOOP;
END;
$$;

alter function ayni_kaynak_controllist(bigint) owner to eafad;

