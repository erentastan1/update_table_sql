create function ayni_kaynak_dagitim_degerleri(p_tesis_id bigint, p_olay_id bigint, p_kategori_birim_id bigint, p_kaynak_kategori_id bigint)
    returns TABLE(mevcut_miktar numeric, dagitilan_miktar numeric, status boolean)
    language plpgsql
as
$$
DECLARE
    var_r record;
begin

	FOR var_r in ( select (select sum(ak.miktar) miktar from ayni_kaynak ak inner join ayni_bagis ab on ab.id = ak.ayni_bagis_id inner join kaynak_kategori kk on kk.id = ak.kaynak_kategori_id
where ak.tesis_id =  p_tesis_id and ab.olay_id = p_olay_id  and ak.kategori_birim_id = p_kategori_birim_id and ak.kaynak_kategori_id = p_kaynak_kategori_id)
mevcut,
(select sum(adk.miktar) miktar from ayni_dagitim_kaynak adk  inner join ayni_dagitim ad  on ad.id= adk.ayni_dagitim_id where adk.tesis_id = p_tesis_id and adk.kategori_birim_id = p_kategori_birim_id and adk.kaynak_kategori_id = p_kaynak_kategori_id)
dagitilan  )
	loop
		mevcut_miktar = var_r.mevcut;
		dagitilan_miktar = var_r.dagitilan;
		if mevcut_miktar > dagitilan_miktar or dagitilan_miktar is null then
			status := true;
		else
			status = false;
		end if;
        RETURN NEXT;
	END LOOP;
END;
$$;

alter function ayni_kaynak_dagitim_degerleri(bigint, bigint, bigint, bigint) owner to eafad;

