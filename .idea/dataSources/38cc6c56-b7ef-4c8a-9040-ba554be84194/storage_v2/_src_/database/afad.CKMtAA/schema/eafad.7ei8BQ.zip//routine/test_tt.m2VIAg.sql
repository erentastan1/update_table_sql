create function test_tt(p_bagis_id bigint)
    returns TABLE(ad character varying, id integer)
    language plpgsql
as
$$
DECLARE 
    var_r record;
begin
	
	FOR var_r in ( select t.*  from ayni_kaynak ak  inner  join tesis t on ak.tesis_id = t.id  where ak.ayni_bagis_id = p_bagis_id )
	loop
	
        ad := upper(var_r.ad) ; 
		id := var_r.id;
	
        RETURN NEXT;
	END LOOP;
END;
$$;

alter function test_tt(bigint) owner to eafad;

