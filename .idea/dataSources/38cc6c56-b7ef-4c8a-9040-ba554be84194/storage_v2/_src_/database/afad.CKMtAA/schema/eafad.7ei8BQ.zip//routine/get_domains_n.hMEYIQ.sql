create function get_domains_n(lname character varying, geom character varying, gid character varying, radius numeric) returns SETOF record
    language plpgsql
as
$$
DECLARE
    lid_new    integer;
    dmn_number integer := 1;
    outr       record;
    innr       record;
    r          record;
BEGIN

    DROP TABLE IF EXISTS tmp_cluster;

    CREATE TEMPORARY TABLE tmp_cluster AS SELECT id, geometri FROM tesis where ST_GeometryType(geometri) = 'ST_Point' limit 1000;
    
    --EXECUTE 'CREATE TEMPORARY TABLE tmp_cluster AS SELECT '||gid||', '||geom||' FROM '||lname||' where ST_GeometryType(geometri) = 'ST_Point' limit 1000;
    ALTER TABLE tmp_cluster ADD COLUMN dmn integer;
    ALTER TABLE tmp_cluster ADD COLUMN chk boolean DEFAULT FALSE;
    EXECUTE 'UPDATE tmp_cluster SET dmn = '||dmn_number||', chk = FALSE WHERE '||gid||' = (SELECT MIN('||gid||') FROM tmp_cluster)';

    LOOP
        LOOP
            FOR outr IN EXECUTE 'SELECT '||gid||' AS gid, '||geom||' AS geom FROM tmp_cluster WHERE dmn = '||dmn_number||' AND NOT chk' LOOP
                    FOR innr IN EXECUTE 'SELECT '||gid||' AS gid, '||geom||' AS geom FROM tmp_cluster WHERE dmn IS NULL' LOOP
                            IF ST_DWithin(ST_Transform(ST_SetSRID(outr.geom, 4326), 3785), ST_Transform(ST_SetSRID(innr.geom, 4326), 3785), radius) THEN
                                --IF ST_DWithin(outr.geom, innr.geom, radius) THEN
                                EXECUTE 'UPDATE tmp_cluster SET dmn = '||dmn_number||', chk = FALSE WHERE '||gid||' = '||innr.gid;
                            END IF;
                        END LOOP;
                    EXECUTE 'UPDATE tmp_cluster SET chk = TRUE WHERE '||gid||' = '||outr.gid;
                END LOOP;
            SELECT INTO r dmn FROM tmp_cluster WHERE dmn = dmn_number AND NOT chk LIMIT 1;
            EXIT WHEN NOT FOUND;
        END LOOP;
        SELECT INTO r dmn FROM tmp_cluster WHERE dmn IS NULL LIMIT 1;
        IF FOUND THEN
            dmn_number := dmn_number + 1;
            EXECUTE 'UPDATE tmp_cluster SET dmn = '||dmn_number||', chk = FALSE WHERE '||gid||' = (SELECT MIN('||gid||') FROM tmp_cluster WHERE dmn IS NULL LIMIT 1)';
        ELSE
            EXIT;
        END IF;
    END LOOP;

    RETURN QUERY EXECUTE 'SELECT ST_ConvexHull(ST_Collect('||geom||')) FROM tmp_cluster GROUP by dmn';

    RETURN;
END
$$;

alter function get_domains_n(varchar, varchar, varchar, numeric) owner to eafad;

