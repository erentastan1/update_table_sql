create function earthquake_version_control_for_scenario_audfnc() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'DELETE') THEN
INSERT INTO EAFAD.EARTHQUAKE_VERSION_CONTROL_FOR_SCENARIO_AUD SELECT  'D', now(), user,txid_current(),OLD.*;
 RETURN OLD;
ELSIF (TG_OP = 'UPDATE') THEN
INSERT INTO EAFAD.EARTHQUAKE_VERSION_CONTROL_FOR_SCENARIO_AUD SELECT  'U', now(), user,txid_current(),NEW.*;
RETURN NEW;
ELSIF (TG_OP = 'INSERT') THEN
INSERT INTO EAFAD.EARTHQUAKE_VERSION_CONTROL_FOR_SCENARIO_AUD SELECT  'I', now(), user, txid_current(),NEW.*;
RETURN NEW;
END IF;
RETURN NULL;
END;
$$;

alter function earthquake_version_control_for_scenario_audfnc() owner to eafad;

