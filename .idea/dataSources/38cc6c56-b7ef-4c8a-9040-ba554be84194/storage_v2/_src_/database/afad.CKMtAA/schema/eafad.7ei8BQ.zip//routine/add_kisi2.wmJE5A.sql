create procedure add_kisi2(adi character varying, soyadi character varying, tcno character varying, email character varying, dogumyeri character varying, kullaniciadi character varying, rolgrupid numeric, unvanid numeric, meslekid numeric, ceptel numeric, INOUT returntype text)
    language plpgsql
as
$$
declare
    kisiId numeric;
    kullaniciId numeric;
    kullaniciRolGrubuId numeric;
    kisiUnvanId numeric;
    kisiMeslekId numeric;
    kisiIletisimId numeric;

begin
    SELECT nextval('kisi_seq') into kisiId;
    SELECT nextval('kullanici_seq') into kullaniciId;
    SELECT nextval('kullanici_rol_grubu_rol_seq') into kullaniciRolGrubuId;
    SELECT nextval('kisi_unvan_seq') into kisiUnvanId;
    SELECT nextval('kisi_meslek_seq') into kisiMeslekId;
    SELECT nextval('kisi_iletisim_seq') into kisiIletisimId;

    insert into kisi (id, tc_kimlik_no, ad, soyad, e_posta,uyruk_id, dogum_yeri, kurum)
    values (kisiId  ,tcno, adi, soyadi, email,20020001,dogumyeri,'AFET VE ACİL DURUM YÖNETİMİ BAŞKANLIĞI');

    insert into kullanici (id, kisi_id, kullanici_adi, sifre, ldap_server_id)
    values (kullaniciId, kisiId, kullaniciAdi, ' ', 1);

    insert into kullanici_rol_grubu_rol (id, kullanici_id, rol_grubu_id)
    VALUES (kullaniciRolGrubuId, kullaniciId,rolgrupid);

    insert into kisi_unvan (id, kisi_id, unvan_id)
    VALUES (kisiUnvanId,kisiId,unvanid);

    insert into kisi_meslek (id, kisi_id, meslek_id)
    VALUES (kisiMeslekId,kisiId,meslekid);

    insert into kisi_iletisim (id, kisi_id, iletisim_tip_id, iletisim_no, oncelik_durumu)
    VALUES (kisiIletisimId,kisiId,20060002,ceptel,true);

    IF (kisiId > 0) then
        returnType := kisiId;
    else
        returnType := 'NOT FOUND';
    end if;



end;
$$;

alter procedure add_kisi2(varchar, varchar, varchar, varchar, varchar, varchar, numeric, numeric, numeric, numeric, inout text) owner to eafad;

