create function dynamic_pivot9(p_kaynak_kategori_id integer, p_tesis_id integer, p_whereclause text)
    returns TABLE(dagitilan_miktar integer)
    language plpgsql
as
$$
DECLARE
  toplam numeric; 
  query text;
begin
 query:='select  sum(gg.number_value)
from kaynak_dagitim kd
inner join (select * from kaynak_dagitim_oznitelik where oznitelik_id = 12) gg on gg.grup_id = kd.grup_id 
where 1=1 ';
 
  query := query || p_whereClause;
 
  query := query || ' and kd.kaynak_kategori_id =' || p_kaynak_kategori_id || ' and kd.tesis_id =' || p_tesis_id;

  query := query ||  '  group by kd.kaynak_kategori_id ';
 
  EXECUTE  query into toplam;
 dagitilan_miktar := toplam;
	return next;
 RAISE NOTICE 'query : %', query;
 
END
$$;

alter function dynamic_pivot9(integer, integer, text) owner to eafad;

